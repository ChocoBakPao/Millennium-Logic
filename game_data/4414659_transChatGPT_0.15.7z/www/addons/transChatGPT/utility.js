const thisAddon = this;

const initialize = async () => {
    const appIcon =  "/"+thisAddon.getRelativePath()+"/chatgpt-icon.png"

    console.log("Initializing ChatGPT ribbon menu")
    ui.ribbonMenu.add("OpenAI", {
        title : `ChatGPT`,
        icon: 'icon-chatgpt',
        permanent: true,
        toolbar : {
            buttons : {
                batchManager : {
                    icon : "icon-layers-alt",
                    title : t("Batch Manager"),
                    onClick : async () => {
                        if (!trans?.project?.projectId) return alert(t("This feature is only available if you have a project open."));
                        thisAddon.batchApi.openBatchManager();
                    }
                },
                
                
            }
        }
    })
}

(async ()=> {
    await addonLoader.resolveState("uiReady");
    initialize();
})();