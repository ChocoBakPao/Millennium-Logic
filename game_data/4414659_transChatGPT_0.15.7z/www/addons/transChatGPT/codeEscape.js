
class JSTemplateCloaking extends CodeEscape {
	constructor(texts, options)  {
		super(texts, options);
		options = options || {}
		this.texts = texts;
		this.placeholders = options.placeholders||{};
		this.unescapePattern = /\${dat\[(\d+)\]}/g;
		this.currentPlaceholderId = 0;
	}
}

JSTemplateCloaking.prototype.generatePlaceholder = function(match) {
	//console.log("generating placeholder", match)
	this.currentPlaceholderId++;
	this.placeholders[this.currentPlaceholderId] = match;
	return this.currentPlaceholderId;
}

JSTemplateCloaking.prototype.getPlaceholder = function(match, index) {
	console.log("Get placeholder of", match)
    var result =  this.placeholders[index]
    delete this.placeholders[index];
    return result;
}

JSTemplateCloaking.prototype.processMatchRule = function(match) {
	var thisPlaceHolder = this.generatePlaceholder(match);
	return "${dat["+thisPlaceHolder+"]}";
}

JSTemplateCloaking.prototype.restore = function(text) {
	try {
		var that = this;
		var result = function() {
			// trying to fix the problem
			text = text.trim();
			if (text.substr(0, text.length-1) == "`" || text.substr(0, text.length-2) == "`,") {
				text = text+"]";
			}

			var dat = that.placeholders;
			console.log("Eval the text:\n"+ text);
			translation = eval(text);

			if (!translation) return "";
			return translation.join($DV.config.lineSeparator);
		}();
		return result;
	} catch (e) {
		console.warn("Unable to restore text with error:", e)
		ui.logError("Bad translation result. A Javascript array is expected, but ChatGPT generated it wrongly. (Not too smart aren't you, ChatGPT?)\nTry lowering the Max Request Length in the options in the hope that ChatGPT will be able to handle that. :", e.toString());
		ui.logError("ChatGPT result: ", text)

		return "";
	}
}

JSTemplateCloaking.prototype.afterTranslation = function(translations) {
	var result = {
        'sourceText'        : "", 
        'translationText'   :this.restore(translations),
        'source'            :this.sourceText, 
        'translation'       : []
    };

	result.translation 		= result.translationText.split(this.lineSeparator);
	result.translation		= result.translation.map((line) => {
		return line.replaceAll(this.translatorEngine.lineSubstitute, this.lineSeparator);
	})

	return result;
}

JSTemplateCloaking.prototype.escapeTexts = function(texts=[], options={}) {
	console.log("PreProcessText with arguments", arguments);
	if (typeof texts == "string") texts = [texts];
		
	var lineSubstituteEscape = String.fromCharCode(0xE000, 190, 0xE001);
	var stringText = ""
	if (Array.isArray(texts)) {
		var newText = [];
		for (var i=0; i<texts.length; i++) {
			texts[i] ||= ""
			console.log("--handling ", texts[i]);
			newText.push(texts[i].replaceAll(this.lineSeparator, lineSubstituteEscape));
		}
		console.log("--newtext ", newText);
		texts = newText;
		stringText = texts.join(this.lineSeparator);
	}
	var pText = (this.escape(stringText)).replaceAll(lineSubstituteEscape, this.translatorEngine.lineSubstitute);
	var nText = JSON.stringify(pText.split(this.lineSeparator), undefined, 2);
	nText = nText.replaceAll("`", "\\`");
	nText = nText.replace(`[\n  "`, "[\n  `");
	nText = nText.replace(`"\n]`, "`\n]");
	nText = nText.replaceAll(`",\n  "`, "`,\n  `");

	this.text = nText;

	return this;
}

TranslatorEngine.addEscapeAlgorithm("JSTemplateCloaking", JSTemplateCloaking);


class JSONCloaking extends CodeEscape {
	constructor(texts, options)  {
		super(texts, options);
		options = options || {}
		this.texts = texts;
		this.placeholders = options.placeholders||{};
		this.unescapePattern = /\${dat\[(\d+)\]}/g;
		this.currentPlaceholderId = 0;
	}
}

JSONCloaking.prototype.generatePlaceholder = function(match) {
	//console.log("generating placeholder", match)
	this.currentPlaceholderId++;
	this.placeholders[this.currentPlaceholderId] = match;
	return this.currentPlaceholderId;
}

JSONCloaking.prototype.getPlaceholder = function(match, index) {
	console.log("Get placeholder of", match)
    var result =  this.placeholders[index]
    delete this.placeholders[index];
    return result;
}

JSONCloaking.prototype.processMatchRule = function(match) {
	var thisPlaceHolder = this.generatePlaceholder(match);
	return "${dat["+thisPlaceHolder+"]}";
}

JSONCloaking.prototype.restore = function(text) {
	try {
		var result = () => {
			// trying to fix the problem
			let textArray
			if (Array.isArray(text)) {
				console.log("result is already an array")
				textArray = text;
			} else {
				text = text.trim();
				textArray = JSON.parse(text);
			}
			// let translations = [];
			// for (var i in textArray) {
			// 	translations.push(this.unescape(textArray[i]));
			// }
			console.log("%cParsed textarray: ", "color:green", textArray);

			let tempArr = [];
			for (let i in textArray) {
				tempArr.push(this.unescape(textArray[i]))
			}
			const translations = tempArr.flat();

			console.log("%cArray of text unescaped: ", "color:green", translations);
			return translations;
		};
		return result();
	} catch (e) {
		console.warn("Unable to restore text with error:", e)
		ui.logError("Bad translation result. A JSON is expected, but ChatGPT generated it wrongly. (Not too smart aren't you, ChatGPT?)\nTry lowering the Max Request Length in the options in the hope that ChatGPT will be able to handle that. :", e.toString());
		ui.logError("ChatGPT result: ", text)
		return "";
	}
}

JSONCloaking.prototype.afterTranslation = function(translations) {
	const restored = this.restore(translations)
	var result = {
        'sourceText'        : "", 
        'translationText'   : restored.join($DV.config.lineSeparator),
        'source'            : this.sourceText,
        'translation'       : restored
    };
	// var lineSubstituteEscape = String.fromCharCode(0xE000, 190, 0xE001);
	//result.translation 		= result.translationText.split(this.lineSeparator);
	// result.translation		= result.translation.map((line) => {
	// 	return line.replaceAll(lineSubstituteEscape, this.lineSeparator);
	// })
	console.log("%cAfter translation: ", "color:green", result);

	return result;
}

/**
 * escapeTexts is entry point for all of the original texts to be escaped
 * @param {String[]} texts - Array of string of the original texts 
 * @param {*} options 
 * @returns 
 */
JSONCloaking.prototype.escapeTexts = function(texts=[], options={}) {
	console.log("PreProcessText with arguments", arguments);
	if (typeof texts == "string") texts = [texts];
		
	//var lineSubstituteEscape = String.fromCharCode(0xE000, 190, 0xE001);
	var stringText = ""
	var textArray = [];
	if (Array.isArray(texts)) {
		for (var i=0; i<texts.length; i++) {
			console.log("--handling ", texts[i]);
			//textArray.push(this.escape(texts[i].replaceAll(this.lineSeparator, lineSubstituteEscape)));
			textArray.push(this.escape(texts[i]));
		}
		console.log("--newtext ", textArray);
		//stringText = texts.join(this.lineSeparator);
	}


	this.toTranslate 	= JSON.stringify(textArray);
	this.text 			= this.toTranslate;
	return this;
}

TranslatorEngine.addEscapeAlgorithm("JSONCloaking", JSONCloaking);


class HTMLCloakingWrapped extends CodeEscape {
	constructor(texts, options)  {
		super(texts, options);
		options = options || {}
		this.texts = texts;
		this.placeholders = options.placeholders||{};
		this.unescapePattern = /<hr id="([\d]+)">/g;
		this.currentPlaceholderId = 0;
		this.hexPlaceholder = this;

		this._restore = this.restore;
		this.restore = (text)=> {
			// splitting the p tags into array of texts
			console.log("Restoring:", text);
			const html = $.parseHTML(text);
			let texts = []
			for (var i in html) {
				texts.push(this._restore.call(this, html[i].innerHTML));
			}
			return texts;
		}
	}
}

HTMLCloakingWrapped.prototype.generatePlaceholder = function(match) {
	console.log("generating placeholder", match)
	this.currentPlaceholderId++;
	this.placeholders[this.currentPlaceholderId] = match;
	return this.currentPlaceholderId;
}

HTMLCloakingWrapped.prototype.getPlaceholder = function(match, index) {
	console.log("Get placeholder of", match)
    var result =  this.placeholders[index]
    delete this.placeholders[index];
    return result;
}

HTMLCloakingWrapped.prototype.processMatchRule = function(match) {
	var thisPlaceHolder = this.generatePlaceholder(match);
	return `<hr id="${thisPlaceHolder}">`;
}

HTMLCloakingWrapped.prototype.escapeTexts = function(texts=[], options={}) {
	console.log("PreProcessText with arguments", arguments);
	if (Array.isArray(texts) == false) texts = [texts]
	
	let wrappedTexts = [];
	for (let i in texts) {
		wrappedTexts.push(`<p>${this.escape(texts[i])}</p>`);
	}

	this.toTranslate 	= wrappedTexts.join("\n");
	this.text 			= this.toTranslate;

	return this;
}

HTMLCloakingWrapped.prototype.afterTranslation = function(translations) {
	var result = {
        'sourceText'        :this.texts, 
        'translationText'   :"",
        'source'            :this.texts, 
        'translation'       :this.restore(translations)
    };


	return result;
}

TranslatorEngine.addEscapeAlgorithm("HTMLCloakingWrapped", HTMLCloakingWrapped);